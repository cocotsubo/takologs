/* TakoLogs overlay — Profil (Statistiques, Tolérance), Paramètres, Sélecteur de substance.
   Auto-contained vanilla JS. Talks to Supabase via REST (anon key). */
(function () {
  'use strict';

  var SUPA_URL = 'https://0ec90b57d6e95fcbda19832f.supabase.co';
  var SUPA_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJib2x0IiwicmVmIjoiMGVjOTBiNTdkNmU5NWZjYmRhMTk4MzJmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTg4ODE1NzQsImV4cCI6MTc1ODg4MTU3NH0.9I8-U0x86Ak8t2DGaIk0HfvTSLsAyzdnz-Nw00mMkKw';
  var REST = SUPA_URL + '/rest/v1/';

  var LS = {
    device: 'tako-device-id',
    hue: 'takologs-accent-hue',
    lang: 'takologs-lang',
    autoLang: 'takologs-auto-lang',
    motion: 'takologs-reduced-motion',
    compact: 'takologs-compact-mode'
  };

  var I18N = {
    fr: {
      profile: 'Profil', settings: 'Paramètres', language: 'Langue', autoLang: 'Détection automatique',
      accent: 'Couleur du site', reset: 'Réinitialiser', reducedMotion: 'Animations réduites',
      compact: 'Affichage compact', saved: 'Enregistré', stats: 'Statistiques',
      tolerance: 'Tolérance', selectSubstance: 'Sélecteur de substance', substance: 'Substance',
      experience: 'Expérience', add: 'Ajouter', cancel: 'Annuler', dose: 'Dose', route: 'Voie',
      time: 'Moment', notes: 'Notes', name: 'Nom', newExp: 'Nouvelle expérience',
      chooseExp: 'Choisir ou créer une expérience', create: 'Créer', delete: 'Supprimer',
      totalEntries: 'Entrées totales', uniqueSubstances: 'Substances uniques',
      experiences: 'Expériences', lastDays: 'Activité (14 jours)', noData: 'Aucune donnée pour le moment.',
      toleranceDesc: 'Indique si la tolérance à une substance est revenue à son niveau de base.',
      resetDays: 'Jours de reset', lastTaken: 'Dernière prise', status: 'État',
      passed: 'Tolérance revenue', pending: 'Tolérance active', update: 'Mettre à jour',
      close: 'Fermer', openProfile: 'Profil TakoLogs', addSubstance: 'Ajouter une substance',
      mood: 'Humeur', date: 'Date', noExp: 'Aucune expérience — créez-en une ci-dessus.',
      added: 'Substance ajoutée à l\'expérience.', errAdd: 'Erreur lors de l\'ajout.',
      delConfirm: 'Supprimer cette entrée ?', substancePlaceholder: 'Rechercher ou saisir une substance…',
      settingsSaved: 'Paramètres enregistrés.', langDetected: 'Langue détectée',
      myStats: 'Mes statistiques', myTolerance: 'Ma tolérance'
    },
    en: {
      profile: 'Profile', settings: 'Settings', language: 'Language', autoLang: 'Automatic detection',
      accent: 'Site color', reset: 'Reset', reducedMotion: 'Reduced motion',
      compact: 'Compact mode', saved: 'Saved', stats: 'Statistics',
      tolerance: 'Tolerance', selectSubstance: 'Substance selector', substance: 'Substance',
      experience: 'Experience', add: 'Add', cancel: 'Cancel', dose: 'Dose', route: 'Route',
      time: 'Time', notes: 'Notes', name: 'Name', newExp: 'New experience',
      chooseExp: 'Choose or create an experience', create: 'Create', delete: 'Delete',
      totalEntries: 'Total entries', uniqueSubstances: 'Unique substances',
      experiences: 'Experiences', lastDays: 'Activity (14 days)', noData: 'No data yet.',
      toleranceDesc: 'Shows whether tolerance to a substance has returned to baseline.',
      resetDays: 'Reset days', lastTaken: 'Last taken', status: 'Status',
      passed: 'Tolerance reset', pending: 'Tolerance active', update: 'Update',
      close: 'Close', openProfile: 'TakoLogs Profile', addSubstance: 'Add a substance',
      mood: 'Mood', date: 'Date', noExp: 'No experience — create one above.',
      added: 'Substance added to experience.', errAdd: 'Error adding substance.',
      delConfirm: 'Delete this entry?', substancePlaceholder: 'Search or enter a substance…',
      settingsSaved: 'Settings saved.', langDetected: 'Detected language',
      myStats: 'My statistics', myTolerance: 'My tolerance'
    },
    es: {
      profile: 'Perfil', settings: 'Ajustes', language: 'Idioma', autoLang: 'Detección automática',
      accent: 'Color del sitio', reset: 'Restablecer', reducedMotion: 'Animaciones reducidas',
      compact: 'Modo compacto', saved: 'Guardado', stats: 'Estadísticas',
      tolerance: 'Tolerancia', selectSubstance: 'Selector de sustancia', substance: 'Sustancia',
      experience: 'Experiencia', add: 'Añadir', cancel: 'Cancelar', dose: 'Dosis', route: 'Vía',
      time: 'Momento', notes: 'Notas', name: 'Nombre', newExp: 'Nueva experiencia',
      chooseExp: 'Elegir o crear una experiencia', create: 'Crear', delete: 'Eliminar',
      totalEntries: 'Entradas totales', uniqueSubstances: 'Sustancias únicas',
      experiences: 'Experiencias', lastDays: 'Actividad (14 días)', noData: 'Sin datos aún.',
      toleranceDesc: 'Muestra si la tolerancia a una sustancia ha vuelto a la línea base.',
      resetDays: 'Días de reset', lastTaken: 'Última toma', status: 'Estado',
      passed: 'Tolerancia restablecida', pending: 'Tolerancia activa', update: 'Actualizar',
      close: 'Cerrar', openProfile: 'Perfil TakoLogs', addSubstance: 'Añadir una sustancia',
      mood: 'Humor', date: 'Fecha', noExp: 'Sin experiencia — crea una arriba.',
      added: 'Sustancia añadida a la experiencia.', errAdd: 'Error al añadir.',
      delConfirm: '¿Eliminar esta entrada?', substancePlaceholder: 'Buscar o introducir una sustancia…',
      settingsSaved: 'Ajustes guardados.', langDetected: 'Idioma detectado',
      myStats: 'Mis estadísticas', myTolerance: 'Mi tolerancia'
    }
  };

  function t(key) { return (I18N[currentLang()] || I18N.fr)[key] || key; }

  function currentLang() {
    // Respecte le mode auto : si activé, on utilise toujours la langue du navigateur
    if (localStorage.getItem(LS.autoLang) !== '0') return detectLang();
    return localStorage.getItem(LS.lang) || detectLang();
  }

  function detectLang() {
    var map = { fr: 'fr', 'fr-FR': 'fr', en: 'en', 'en-US': 'en', 'en-GB': 'en', es: 'es', 'es-ES': 'es' };
    var n = (navigator.language || 'fr').toLowerCase();
    if (map[n]) return map[n];
    if (n.indexOf('fr') === 0) return 'fr';
    if (n.indexOf('en') === 0) return 'en';
    if (n.indexOf('es') === 0) return 'es';
    return 'fr';
  }

  function deviceId() {
    var id = localStorage.getItem(LS.device);
    if (!id) { id = 'd-' + Date.now() + '-' + Math.random().toString(36).slice(2, 10); localStorage.setItem(LS.device, id); }
    return id;
  }

  /* ---- Supabase REST helpers ---- */
  async function supa(path, opts) {
    opts = opts || {};
    var headers = Object.assign({
      'apikey': SUPA_KEY,
      'Authorization': 'Bearer ' + SUPA_KEY,
      'Content-Type': 'application/json'
    }, opts.headers || {});
    if (opts.method && opts.method !== 'GET' && opts.body && typeof opts.body !== 'string') opts.body = JSON.stringify(opts.body);
    var r = await fetch(REST + path, { method: opts.method || 'GET', headers: headers, body: opts.body });
    if (!r.ok) { var e = await r.text(); throw new Error(e); }
    if (r.status === 204) return null;
    return r.json();
  }

  function supaSelect(table, qs) { return supa(table + (qs ? '?' + qs : '')); }
  function supaInsert(table, rows) { return supa(table, { method: 'POST', body: Array.isArray(rows) ? rows : [rows], headers: { 'Prefer': 'return=representation' } }); }
  function supaDelete(table, qs) { return supa(table + '?' + qs, { method: 'DELETE' }); }
  function supaUpsert(table, row, onConflict) {
    return supa(table, { method: 'POST', body: [row], headers: { 'Prefer': 'resolution=merge-duplicates' + (onConflict ? ',return=representation' : '') } });
  }

  /* ---- Theme application ---- */
  function applyHue(h) {
    var hue = Number.isFinite(+h) ? ((+h % 360) + 360) % 360 : 36;
    document.documentElement.style.setProperty('--accent-h', String(Math.round(hue)));
    localStorage.setItem(LS.hue, String(Math.round(hue)));
    updateFabColor();
  }
  function applyMotion(on) {
    document.documentElement.classList.toggle('tako-reduced-motion', !!on);
    localStorage.setItem(LS.motion, on ? '1' : '0');
  }
  function applyCompact(on) {
    document.documentElement.classList.toggle('tako-compact', !!on);
    localStorage.setItem(LS.compact, on ? '1' : '0');
  }

  function updateFabColor() {
    var fab = document.getElementById('tako-add-substance-fab');
    if (fab) {
      var h = document.documentElement.style.getPropertyValue('--accent-h') || '36';
      fab.style.background = 'hsl(' + h + ', 55%, 48%)';
      fab.style.boxShadow = '0 10px 25px hsla(' + h + ', 45%, 40%, 0.4), 0 4px 10px rgba(44, 36, 23, 0.15)';
    }
  }

  function saveSettingsToCloud(s) {
    s.device_id = deviceId(); s.updated_at = new Date().toISOString();
    return supaUpsert('user_settings', s, 'device_id').catch(function () {});
  }

  /* ---- UI scaffolding ---- */
  function el(tag, cls, html) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    return e;
  }

  var panel, scrim, launcher;
  var currentTab = 'profile';

  function openPanel() { if (!panel) buildPanel(); scrim.classList.add('tako-show'); panel.classList.add('tako-show'); document.body.style.overflow = 'hidden'; setTab(currentTab); }
  function closePanel() { if (scrim) scrim.classList.remove('tako-show'); if (panel) panel.classList.remove('tako-show'); document.body.style.overflow = ''; }

  function buildLauncher() {
    launcher = el('button', 'tako-launcher', '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>');
    launcher.title = t('openProfile');
    launcher.setAttribute('aria-label', t('openProfile'));
    launcher.addEventListener('click', openPanel);
    document.body.appendChild(launcher);
  }

  var tabs = {};
  function setTab(name) {
    currentTab = name;
    Object.keys(tabs).forEach(function (k) {
      tabs[k].btn.classList.toggle('tako-active', k === name);
      tabs[k].view.style.display = k === name ? 'block' : 'none';
    });
    if (name === 'profile') { renderStats(); renderTolerance(); }
    if (name === 'selector') renderSelector();
  }

  function buildPanel() {
    scrim = el('div', 'tako-scrim'); scrim.addEventListener('click', closePanel); document.body.appendChild(scrim);
    panel = el('div', 'tako-panel');
    var head = el('div', 'tako-head', '<span class="tako-title">TakoLogs</span>');
    var closeBtn = el('button', 'tako-close', '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>');
    closeBtn.setAttribute('aria-label', t('close'));
    closeBtn.addEventListener('click', closePanel);
    head.appendChild(closeBtn); panel.appendChild(head);

    var nav = el('div', 'tako-nav');
    [['profile', 'profile'], ['settings', 'settings'], ['selector', 'selectSubstance']].forEach(function (pair) {
      var id = pair[0], labelKey = pair[1];
      var btn = el('button', 'tako-tab', t(labelKey));
      btn.addEventListener('click', function () { setTab(id); });
      nav.appendChild(btn);
      tabs[id] = { btn: btn, view: el('div', 'tako-view') };
    });
    panel.appendChild(nav);
    var body = el('div', 'tako-body');
    Object.keys(tabs).forEach(function (k) { body.appendChild(tabs[k].view); });
    panel.appendChild(body);
    document.body.appendChild(panel);

    buildProfileView(tabs.profile.view);
    buildSettingsView(tabs.settings.view);
    buildSelectorView(tabs.selector.view);
    setTab('profile');
  }

  /* ---- Profile view (stats + tolerance) ---- */
  function buildProfileView(view) {
    view.innerHTML = '';

    var statsSection = el('div', 'tako-profile-section');
    statsSection.appendChild(el('div', 'tako-section-title', t('myStats')));
    var statsContainer = el('div', 'tako-stats-container');
    statsContainer.appendChild(el('div', 'tako-empty', t('noData')));
    statsSection.appendChild(statsContainer);
    view.appendChild(statsSection);

    var tolSection = el('div', 'tako-profile-section');
    tolSection.appendChild(el('div', 'tako-section-title', t('myTolerance')));
    var tolContainer = el('div', 'tako-tol-container');
    tolContainer.appendChild(el('div', 'tako-empty', t('noData')));
    tolSection.appendChild(tolContainer);
    view.appendChild(tolSection);

    view._statsContainer = statsContainer;
    view._tolContainer = tolContainer;
  }

  /* ---- Statistics ---- */
  async function renderStats() {
    var container = tabs.profile.view._statsContainer;
    if (!container) return;
    container.innerHTML = '';
    container.appendChild(el('div', 'tako-loading', '…'));
    try {
      var subs = await supaSelect('journal_substances', 'select=id,substance_name,created_at');
      var exps = await supaSelect('experiences', 'select=id,created_at');
      if (!subs.length && !exps.length) { container.innerHTML = ''; container.appendChild(el('div', 'tako-empty', t('noData'))); return; }
      container.innerHTML = '';
      var stats = [
        { label: t('totalEntries'), value: subs.length },
        { label: t('uniqueSubstances'), value: new Set(subs.map(function (s) { return s.substance_name.toLowerCase(); })).size },
        { label: t('experiences'), value: exps.length }
      ];
      var grid = el('div', 'tako-stats-grid');
      stats.forEach(function (s) {
        var card = el('div', 'tako-stat-card', '<div class="tako-stat-val">' + s.value + '</div><div class="tako-stat-label">' + esc(s.label) + '</div>');
        grid.appendChild(card);
      });
      container.appendChild(grid);

      var days = []; var counts = {};
      for (var i = 13; i >= 0; i--) {
        var d = new Date(); d.setDate(d.getDate() - i);
        var key = d.toISOString().slice(0, 10); days.push(key); counts[key] = 0;
      }
      subs.forEach(function (s) { var k = (s.created_at || '').slice(0, 10); if (counts[k] != null) counts[k]++; });
      var max = 1; days.forEach(function (d) { if (counts[d] > max) max = counts[d]; });
      var chart = el('div', 'tako-chart');
      chart.appendChild(el('div', 'tako-label', t('lastDays')));
      var bars = el('div', 'tako-bars');
      days.forEach(function (d) {
        var h = Math.max(2, (counts[d] / max) * 100);
        var bar = el('div', 'tako-bar', '<div class="tako-bar-fill" style="height:' + h + '%"></div><div class="tako-bar-day">' + d.slice(8) + '</div>');
        bars.appendChild(bar);
      });
      chart.appendChild(bars);
      container.appendChild(chart);

      var freq = {};
      subs.forEach(function (s) { var k = s.substance_name.toLowerCase(); freq[k] = (freq[k] || 0) + 1; });
      var top = Object.keys(freq).sort(function (a, b) { return freq[b] - freq[a]; }).slice(0, 5);
      if (top.length) {
        container.appendChild(el('div', 'tako-label', t('substance')));
        var list = el('div', 'tako-list');
        top.forEach(function (k) {
          list.appendChild(el('div', 'tako-card', '<div class="tako-card-name">' + esc(k) + '</div><div class="tako-card-meta">' + freq[k] + '×</div>'));
        });
        container.appendChild(list);
      }
    } catch (e) { container.innerHTML = ''; container.appendChild(el('div', 'tako-empty', e.message)); }
  }

  /* ---- Tolerance ---- */
  async function renderTolerance() {
    var container = tabs.profile.view._tolContainer;
    if (!container) return;
    container.innerHTML = '';
    container.appendChild(el('div', 'tako-loading', '…'));
    try {
      var rows = await supaSelect('tolerance_windows', 'order=last_taken_date.desc&select=id,substance_name,last_taken_date,reset_days');
      if (!rows.length) { container.innerHTML = ''; container.appendChild(el('div', 'tako-empty', t('noData'))); return; }
      container.innerHTML = '';
      container.appendChild(el('div', 'tako-hint', t('toleranceDesc')));
      var today = new Date(); today.setHours(0, 0, 0, 0);
      var list = el('div', 'tako-list');
      rows.forEach(function (r) {
        var last = new Date(r.last_taken_date + 'T00:00:00');
        var days = Math.floor((today - last) / 86400000);
        var remaining = r.reset_days - days;
        var passed = remaining <= 0;
        var card = el('div', 'tako-card ' + (passed ? 'tako-tol-passed' : 'tako-tol-pending'));
        var inner = '<div class="tako-card-name">' + esc(r.substance_name) + '</div>';
        inner += '<div class="tako-card-meta">' + t('lastTaken') + ': ' + esc(r.last_taken_date) + '</div>';
        inner += '<div class="tako-card-meta">' + t('resetDays') + ': ' + r.reset_days + '</div>';
        inner += '<div class="tako-tol-badge">' + (passed ? t('passed') : t('pending') + ' (' + Math.max(0, remaining) + 'j)') + '</div>';
        card.innerHTML = inner;
        var upd = el('div', 'tako-tol-edit');
        var inp = el('input', 'tako-input tako-mini'); inp.type = 'number'; inp.min = '1'; inp.value = r.reset_days;
        var btn = el('button', 'tako-btn tako-btn-ghost tako-mini', t('update'));
        btn.addEventListener('click', async function () {
          var v = parseInt(inp.value, 10); if (!v || v < 1) return;
          await supa('tolerance_windows?id=eq.' + r.id, { method: 'PATCH', body: JSON.stringify({ reset_days: v }), headers: { 'Prefer': 'return=minimal' } });
          renderTolerance();
        });
        upd.appendChild(inp); upd.appendChild(btn);
        card.appendChild(upd);
        list.appendChild(card);
      });
      container.appendChild(list);
    } catch (e) { container.innerHTML = ''; container.appendChild(el('div', 'tako-empty', e.message)); }
  }

  /* ---- Settings view (language, color, motion, compact only) ---- */
  function buildSettingsView(view) {
    view.innerHTML = '';

    var langWrap = el('div', 'tako-field');
    langWrap.appendChild(el('label', 'tako-label', t('language')));
    var autoChk = el('input'); autoChk.type = 'checkbox'; autoChk.checked = localStorage.getItem(LS.autoLang) !== '0';
    var autoWrap = el('label', 'tako-check', '<span>' + t('autoLang') + '</span>');
    autoWrap.insertBefore(autoChk, autoWrap.firstChild);
    var sel = el('select', 'tako-select');
    [['fr', 'Français'], ['en', 'English'], ['es', 'Español']].forEach(function (o) {
      var opt = el('option', null, o[1]); opt.value = o[0]; if (o[0] === currentLang()) opt.selected = true; sel.appendChild(opt);
    });
    sel.disabled = autoChk.checked;
    autoChk.addEventListener('change', function () {
      localStorage.setItem(LS.autoLang, autoChk.checked ? '1' : '0');
      sel.disabled = autoChk.checked;
      if (autoChk.checked) { sel.value = detectLang(); localStorage.setItem(LS.lang, sel.value); }
      refreshAllLabels();
      saveSettingsToCloud({ language: sel.value, auto_language: autoChk.checked });
    });
    sel.addEventListener('change', function () {
      localStorage.setItem(LS.lang, sel.value);
      refreshAllLabels();
      saveSettingsToCloud({ language: sel.value, auto_language: autoChk.checked });
    });
    langWrap.appendChild(autoWrap);
    langWrap.appendChild(sel);
    view.appendChild(langWrap);

    var hueWrap = el('div', 'tako-field');
    hueWrap.appendChild(el('label', 'tako-label', t('accent')));
    var hueRange = el('input', 'tako-range'); hueRange.type = 'range'; hueRange.min = '0'; hueRange.max = '359';
    hueRange.value = localStorage.getItem(LS.hue) || 36;
    var huePreview = el('div', 'tako-hue-preview');
    function updateHuePreview() { huePreview.style.background = 'hsl(' + hueRange.value + ', 60%, 50%)'; }
    updateHuePreview();
    hueRange.addEventListener('input', function () { applyHue(hueRange.value); updateHuePreview(); });
    hueRange.addEventListener('change', function () { saveSettingsToCloud({ accent_hue: +hueRange.value }); });
    var resetBtn = el('button', 'tako-btn tako-btn-ghost', t('reset'));
    resetBtn.addEventListener('click', function () { hueRange.value = 36; applyHue(36); updateHuePreview(); saveSettingsToCloud({ accent_hue: 36 }); });
    hueWrap.appendChild(hueRange); hueWrap.appendChild(huePreview); hueWrap.appendChild(resetBtn);
    view.appendChild(hueWrap);

    var motionChk = el('input'); motionChk.type = 'checkbox'; motionChk.checked = localStorage.getItem(LS.motion) === '1';
    motionChk.addEventListener('change', function () { applyMotion(motionChk.checked); saveSettingsToCloud({ reduced_motion: motionChk.checked }); });
    var motionWrap = el('label', 'tako-check', '<span>' + t('reducedMotion') + '</span>');
    motionWrap.insertBefore(motionChk, motionWrap.firstChild);
    view.appendChild(motionWrap);

    var compactChk = el('input'); compactChk.type = 'checkbox'; compactChk.checked = localStorage.getItem(LS.compact) === '1';
    compactChk.addEventListener('change', function () { applyCompact(compactChk.checked); saveSettingsToCloud({ compact_mode: compactChk.checked }); });
    var compactWrap = el('label', 'tako-check', '<span>' + t('compact') + '</span>');
    compactWrap.insertBefore(compactChk, compactWrap.firstChild);
    view.appendChild(compactWrap);

    var hint = el('div', 'tako-hint', t('settingsSaved'));
    view.appendChild(hint);
  }

  function refreshAllLabels() {
    if (!panel) return;
    // Met à jour l'attribut lang du document pour l'accessibilité / SEO
    try { document.documentElement.lang = currentLang(); } catch (e) {}

    var tabKeys = { profile: 'profile', settings: 'settings', selector: 'selectSubstance' };
    Object.keys(tabKeys).forEach(function (k) {
      if (tabs[k] && tabs[k].btn) tabs[k].btn.textContent = t(tabKeys[k]);
    });
    if (launcher) { launcher.title = t('openProfile'); launcher.setAttribute('aria-label', t('openProfile')); }

    var settingsView = tabs.settings.view;
    settingsView.innerHTML = '';
    buildSettingsView(settingsView);

    var profileView = tabs.profile.view;
    buildProfileView(profileView);
    if (currentTab === 'profile') { renderStats(); renderTolerance(); }

    // Important : reconstruire aussi l'onglet sélecteur pour que les labels soient traduits
    if (tabs.selector && tabs.selector.view) {
      buildSelectorView(tabs.selector.view);
    }
  }

  /* ---- Substance selector view ---- */
  var selectorExperiences = [];
  var selectorSelectedExp = null;

  function buildSelectorView(view) {
    view.innerHTML = '';
    view.appendChild(el('div', 'tako-field', '<label class="tako-label">' + t('chooseExp') + '</label>'));
    var expRow = el('div', 'tako-row');
    var expSel = el('select', 'tako-select'); expSel.style.flex = '1';
    var newExpInput = el('input', 'tako-input'); newExpInput.type = 'text'; newExpInput.placeholder = t('newExp');
    var createBtn = el('button', 'tako-btn', t('create'));
    createBtn.addEventListener('click', async function () {
      var name = newExpInput.value.trim(); if (!name) return;
      try {
        var created = await supaInsert('experiences', { name: name, date: new Date().toISOString().slice(0, 10) });
        newExpInput.value = ''; await loadSelectorExperiences(); selectExperience(created[0].id);
      } catch (e) { alert(e.message); }
    });
    expRow.appendChild(expSel); expRow.appendChild(newExpInput); expRow.appendChild(createBtn);
    view.appendChild(expRow);

    var form = el('div', 'tako-form tako-hidden');
    var substInput = el('input', 'tako-input'); substInput.placeholder = t('substancePlaceholder'); substInput.type = 'text';
    var doseInput = el('input', 'tako-input'); doseInput.placeholder = t('dose'); doseInput.type = 'text';
    var routeInput = el('input', 'tako-input'); routeInput.placeholder = t('route'); routeInput.type = 'text';
    var timeInput = el('input', 'tako-input'); timeInput.placeholder = t('time'); timeInput.type = 'text';
    var moodInput = el('input', 'tako-input'); moodInput.placeholder = t('mood'); moodInput.type = 'text';
    var addBtn = el('button', 'tako-btn tako-btn-primary', t('add'));
    var status = el('div', 'tako-hint');

    addBtn.addEventListener('click', async function () {
      var s = substInput.value.trim(); if (!s || !selectorSelectedExp) { status.textContent = t('errAdd'); return; }
      try {
        await supaInsert('journal_substances', {
          experience_id: selectorSelectedExp,
          substance_name: s,
          dose: doseInput.value.trim() || null,
          route: routeInput.value.trim() || null,
          time: timeInput.value.trim() || null,
          category: null
        });
        await supaUpsert('tolerance_windows', { substance_name: s, last_taken_date: new Date().toISOString().slice(0, 10), reset_days: 14 }, 'substance_name');
        substInput.value = ''; doseInput.value = ''; routeInput.value = ''; timeInput.value = '';
        status.textContent = t('added');
        renderSelectorEntries();
      } catch (e) { status.textContent = t('errAdd') + ' ' + e.message; }
    });

    form.appendChild(el('label', 'tako-label', t('substance'))); form.appendChild(substInput);
    var grid = el('div', 'tako-grid2');
    grid.appendChild(doseInput); grid.appendChild(routeInput); grid.appendChild(timeInput); grid.appendChild(moodInput);
    form.appendChild(grid);
    form.appendChild(addBtn); form.appendChild(status);
    view.appendChild(form);

    var entriesTitle = el('div', 'tako-label', '');
    view.appendChild(entriesTitle);
    var entriesList = el('div', 'tako-list');
    view.appendChild(entriesList);

    expSel.addEventListener('change', function () { selectExperience(expSel.value); });

    view._expSel = expSel;
    view._form = form;
    view._entriesList = entriesList;
    view._entriesTitle = entriesTitle;
  }

  function selectExperience(id) {
    selectorSelectedExp = id;
    if (tabs.selector.view._form) tabs.selector.view._form.classList.toggle('tako-hidden', !id);
    renderSelectorEntries();
  }

  async function loadSelectorExperiences() {
    try {
      var rows = await supaSelect('experiences', 'order=created_at.desc&select=id,name,date');
      selectorExperiences = rows || [];
      var sel = tabs.selector.view._expSel;
      sel.innerHTML = '';
      if (!selectorExperiences.length) {
        var opt = el('option', null, t('noExp')); opt.value = ''; sel.appendChild(opt);
        return;
      }
      selectorExperiences.forEach(function (e) {
        var opt = el('option', null, e.name + ' — ' + (e.date || '')); opt.value = e.id; sel.appendChild(opt);
      });
    } catch (e) { selectorExperiences = []; }
  }

  async function renderSelector() {
    await loadSelectorExperiences();
    var sel = tabs.selector.view._expSel;
    if (selectorExperiences.length && !selectorSelectedExp) { selectorSelectedExp = selectorExperiences[0].id; sel.value = selectorSelectedExp; }
    selectExperience(selectorSelectedExp);
  }

  async function renderSelectorEntries() {
    var list = tabs.selector.view._entriesList;
    var title = tabs.selector.view._entriesTitle;
    list.innerHTML = '';
    if (!selectorSelectedExp) { title.textContent = ''; return; }
    try {
      var rows = await supaSelect('journal_substances', 'experience_id=eq.' + selectorSelectedExp + '&order=created_at.desc&select=id,substance_name,dose,route,time');
      title.textContent = (rows.length ? rows.length : 0) + ' entrée(s)';
      if (!rows.length) { list.appendChild(el('div', 'tako-empty', t('noData'))); return; }
      rows.forEach(function (r) {
        var item = el('div', 'tako-card');
        var txt = '<div class="tako-card-name">' + esc(r.substance_name) + '</div>';
        if (r.dose) txt += '<div class="tako-card-meta">' + t('dose') + ': ' + esc(r.dose) + '</div>';
        if (r.route) txt += '<div class="tako-card-meta">' + t('route') + ': ' + esc(r.route) + '</div>';
        if (r.time) txt += '<div class="tako-card-meta">' + t('time') + ': ' + esc(r.time) + '</div>';
        item.innerHTML = txt;
        var del = el('button', 'tako-mini-del', '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>');
        del.addEventListener('click', async function () {
          if (!confirm(t('delConfirm'))) return;
          await supaDelete('journal_substances', 'id=eq.' + r.id);
          renderSelectorEntries();
        });
        item.appendChild(del);
        list.appendChild(item);
      });
    } catch (e) { list.appendChild(el('div', 'tako-empty', e.message)); }
  }

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  /* ---- Init ---- */
  function init() {
    applyHue(localStorage.getItem(LS.hue) || 36);
    applyMotion(localStorage.getItem(LS.motion) === '1');
    applyCompact(localStorage.getItem(LS.compact) === '1');
    // Si auto-lang activé et aucune langue manuelle stockée, on enregistre la langue détectée
    // (utile comme valeur de repli si l'utilisateur désactive ensuite l'auto)
    if (localStorage.getItem(LS.autoLang) !== '0' && !localStorage.getItem(LS.lang)) {
      localStorage.setItem(LS.lang, detectLang());
    }
    try { document.documentElement.lang = currentLang(); } catch (e) {}
    buildLauncher();
    supaSelect('user_settings', 'device_id=eq.' + deviceId() + '&limit=1').then(function (rows) {
      if (rows && rows.length) {
        var s = rows[0];
        if (s.accent_hue != null) applyHue(s.accent_hue);
        // On stocke toujours la langue préférée (utilisée quand auto est désactivé)
        if (s.language) { localStorage.setItem(LS.lang, s.language); }
        if (s.auto_language != null) localStorage.setItem(LS.autoLang, s.auto_language ? '1' : '0');
        if (s.reduced_motion != null) applyMotion(s.reduced_motion);
        if (s.compact_mode != null) applyCompact(s.compact_mode);
        // Applique la langue effective après chargement des settings cloud
        try { document.documentElement.lang = currentLang(); } catch (e) {}
        // Si le panneau est déjà ouvert, on rafraîchit les labels
        if (panel) refreshAllLabels();
      }
    }).catch(function () {});
  }

  if (document.readyState !== 'loading') init();
  else document.addEventListener('DOMContentLoaded', init);
})();
