/*
# Journal des substances, expériences et paramètres (single-tenant, sans auth)

1. Nouvelles tables
- `experiences` : une expérience de journal (séance), avec nom, date, note, humeur.
  - id (uuid, PK)
  - name (text)
  - date (date)
  - mood (text, nullable)
  - notes (text, nullable)
  - created_at (timestamptz)
- `journal_substances` : substances ajoutées à une expérience (lien vers experiences).
  - id (uuid, PK)
  - experience_id (uuid, FK -> experiences.id ON DELETE CASCADE)
  - substance_name (text, nom choisi par l'utilisateur)
  - category (text, catégorie, nullable)
  - dose (text, nullable)
  - route (text, voie, nullable)
  - time (text, heure/(moment), nullable)
  - created_at (timestamptz)
- `tolerance_windows` : fenêtre de tolérance par substance (dernière prise + durée estimée).
  - id (uuid, PK)
  - substance_name (text)
  - last_taken_date (date)
  - reset_days (int, durée estimée de retour à la tolérance de base)
  - notes (text, nullable)
  - created_at (timestamptz)
- `user_settings` : paramètres de personnalisation (une ligne par appareil/navigateur).
  - id (uuid, PK)
  - device_id (text, identifiant local unique)
  - accent_hue (int, couleur d'accent du site)
  - language (text, langue préférée)
  - reduced_motion (bool, animations réduites)
  - compact_mode (bool, affichage compact)
  - auto_language (bool, détection auto de la langue)
  - created_at (timestamptz)
  - updated_at (timestamptz)

2. Sécurité
- RLS activée sur toutes les tables.
- Application single-tenant sans écran de connexion : politiques TO anon, authenticated
  (les données sont volontairement partagées/publiques sur cet appareil).

3. Notes importantes
- Index sur experience_id et substance_name pour les statistiques et la tolérance.
- device_id permet de stocker un jeu de paramètres par navigateur sans compte utilisateur.
*/

CREATE TABLE IF NOT EXISTS experiences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL DEFAULT 'Nouvelle expérience',
  date date NOT NULL DEFAULT CURRENT_DATE,
  mood text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS journal_substances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  experience_id uuid NOT NULL REFERENCES experiences(id) ON DELETE CASCADE,
  substance_name text NOT NULL,
  category text,
  dose text,
  route text,
  time text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS tolerance_windows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  substance_name text NOT NULL UNIQUE,
  last_taken_date date NOT NULL DEFAULT CURRENT_DATE,
  reset_days int NOT NULL DEFAULT 14,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id text NOT NULL UNIQUE,
  accent_hue int NOT NULL DEFAULT 36,
  language text NOT NULL DEFAULT 'fr',
  reduced_motion boolean NOT NULL DEFAULT false,
  compact_mode boolean NOT NULL DEFAULT false,
  auto_language boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_journal_substances_experience_id
  ON journal_substances(experience_id);
CREATE INDEX IF NOT EXISTS idx_journal_substances_name
  ON journal_substances(substance_name);
CREATE INDEX IF NOT EXISTS idx_tolerance_windows_substance
  ON tolerance_windows(substance_name);

ALTER TABLE experiences ENABLE ROW LEVEL SECURITY;
ALTER TABLE journal_substances ENABLE ROW LEVEL SECURITY;
ALTER TABLE tolerance_windows ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;

-- experiences
DROP POLICY IF EXISTS "anon_select_experiences" ON experiences;
CREATE POLICY "anon_select_experiences" ON experiences FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_experiences" ON experiences;
CREATE POLICY "anon_insert_experiences" ON experiences FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_experiences" ON experiences;
CREATE POLICY "anon_update_experiences" ON experiences FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_experiences" ON experiences;
CREATE POLICY "anon_delete_experiences" ON experiences FOR DELETE
  TO anon, authenticated USING (true);

-- journal_substances
DROP POLICY IF EXISTS "anon_select_journal_substances" ON journal_substances;
CREATE POLICY "anon_select_journal_substances" ON journal_substances FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_journal_substances" ON journal_substances;
CREATE POLICY "anon_insert_journal_substances" ON journal_substances FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_journal_substances" ON journal_substances;
CREATE POLICY "anon_update_journal_substances" ON journal_substances FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_journal_substances" ON journal_substances;
CREATE POLICY "anon_delete_journal_substances" ON journal_substances FOR DELETE
  TO anon, authenticated USING (true);

-- tolerance_windows
DROP POLICY IF EXISTS "anon_select_tolerance_windows" ON tolerance_windows;
CREATE POLICY "anon_select_tolerance_windows" ON tolerance_windows FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_tolerance_windows" ON tolerance_windows;
CREATE POLICY "anon_insert_tolerance_windows" ON tolerance_windows FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_tolerance_windows" ON tolerance_windows;
CREATE POLICY "anon_update_tolerance_windows" ON tolerance_windows FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_tolerance_windows" ON tolerance_windows;
CREATE POLICY "anon_delete_tolerance_windows" ON tolerance_windows FOR DELETE
  TO anon, authenticated USING (true);

-- user_settings
DROP POLICY IF EXISTS "anon_select_user_settings" ON user_settings;
CREATE POLICY "anon_select_user_settings" ON user_settings FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_user_settings" ON user_settings;
CREATE POLICY "anon_insert_user_settings" ON user_settings FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_user_settings" ON user_settings;
CREATE POLICY "anon_update_user_settings" ON user_settings FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_user_settings" ON user_settings;
CREATE POLICY "anon_delete_user_settings" ON user_settings FOR DELETE
  TO anon, authenticated USING (true);
